package com.example.repaso5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.repaso5.ui.theme.Repaso5Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Repaso5Theme {
                // Muestra los botones horizontales:
                //HorizontalButtons()

                // Para probar la versión vertical, comenta la línea anterior y descomenta la siguiente:
                VerticalButtons()
            }
        }
    }
}

@Composable
fun HorizontalButtons() {
    Row(
        modifier = Modifier
            .fillMaxWidth() // Ocupa todo el ancho disponible
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp) // Espacio entre botones
    ) {
        Button(modifier = Modifier.weight(1f), onClick = {}) { Text("Botón 1") }
        Button(modifier = Modifier.weight(1f), onClick = {}) { Text("Botón 2") }
        Button(modifier = Modifier.weight(1f), onClick = {}) { Text("Botón 3") }
        Button(modifier = Modifier.weight(1f), onClick = {}) { Text("Botón 4") }
    }
}

@Composable
fun VerticalButtons() {
    Column(
        modifier = Modifier
            .fillMaxHeight() // Ocupa todo el alto disponible
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp) // Espacio entre botones
    ) {
        Button(modifier = Modifier.fillMaxWidth(), onClick = {}) { Text("Botón 1") }
        Button(modifier = Modifier.fillMaxWidth(), onClick = {}) { Text("Botón 2") }
        Button(modifier = Modifier.fillMaxWidth(), onClick = {}) { Text("Botón 3") }
        Button(modifier = Modifier.fillMaxWidth(), onClick = {}) { Text("Botón 4") }
    }
}

@Preview(showBackground = true)
@Composable
fun HorizontalButtonsPreview() {
    Repaso5Theme {
        HorizontalButtons()
    }
}

@Preview(showBackground = true)
@Composable
fun VerticalButtonsPreview() {
    Repaso5Theme {
        VerticalButtons()
    }
}
