package com.example.repaso4

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.repaso4.ui.theme.Repaso4Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Repaso4Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    // Guardamos si estamos en la pantalla 1 o 2
                    var mostrarPantallaMensaje by rememberSaveable { mutableStateOf(false) }

                    if (mostrarPantallaMensaje) {
                        // Pantalla 2
                        PantallaMensaje(
                            modifier = Modifier.padding(innerPadding),
                            onVolver = { mostrarPantallaMensaje = false }
                        )
                    } else {
                        // Pantalla 1
                        PantallaPrincipal(
                            modifier = Modifier.padding(innerPadding),
                            onAbrirMensaje = { mostrarPantallaMensaje = true }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PantallaPrincipal(modifier: Modifier = Modifier, onAbrirMensaje: () -> Unit) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Button(onClick = onAbrirMensaje) {
            Text(text = "Abrir mensaje")
        }
    }
}

@Composable
fun PantallaMensaje(modifier: Modifier = Modifier, onVolver: () -> Unit) {
    Column(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Lo que os dé la gana")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onVolver) {
            Text(text = "Volver")
        }
    }
}
