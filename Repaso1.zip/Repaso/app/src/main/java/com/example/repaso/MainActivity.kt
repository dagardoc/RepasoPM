package com.example.repaso

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.repaso.ui.theme.RepasoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RepasoTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    // Variable con el nombre
                    val nombre = "Daniel"
                    // Llamada al composable
                    Saludo(
                        nombre = nombre,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun Saludo(nombre: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(16.dp)) {
        Text(text = "Bienvenido a mi app", fontSize = 24.sp)
        Text(text = "Hola, me llamo $nombre", fontSize = 20.sp)
    }
}

@Preview(showBackground = true)
@Composable
fun SaludoPreview() {
    RepasoTheme {
        Saludo("Juan")
    }
}
