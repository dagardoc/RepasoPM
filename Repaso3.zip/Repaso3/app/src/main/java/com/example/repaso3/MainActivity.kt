package com.example.repaso3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.repaso3.ui.theme.Repaso3Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // Ajuste de UI al borde de la pantalla
        setContent {
            Repaso3Theme {
                // Scaffold es opcional si no necesitas topBar o bottomBar
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    TapEmoji(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun TapEmoji(modifier: Modifier = Modifier) {
    // Contador que se guarda al girar el dispositivo
    var tapCount by rememberSaveable { mutableStateOf(0) }

    // Cambiar emoji y mensaje según el número de taps
    val emoji = if (tapCount < 5) "📦" else "🎁"
    val showMessage = tapCount >= 5

    // Layout centrado
    Column(
        modifier = modifier
            .fillMaxSize()
            .clickable { tapCount++ }, // Cada toque suma 1
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = emoji,
            fontSize = 80.sp
        )
        if (showMessage) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "¡Sorpresa!",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
