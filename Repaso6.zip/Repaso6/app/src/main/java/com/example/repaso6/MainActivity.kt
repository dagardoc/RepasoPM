package com.example.repaso6

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.repaso6.ui.theme.Repaso6Theme
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Repaso6Theme {
                GameScreen()
            }
        }
    }
}

@Composable
fun GameScreen() {
    var tapCount by remember { mutableStateOf(0) }
    var position by remember { mutableStateOf(Alignment.Center) }

    // Lista de posibles posiciones
    val positions = listOf(
        Alignment.TopStart,
        Alignment.TopEnd,
        Alignment.BottomStart,
        Alignment.BottomEnd,
        Alignment.Center
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .clickable {
                // Cambia posición aleatoria
                position = positions[Random.nextInt(positions.size)]
                // Incrementa contador
                tapCount++
            }
    ) {
        if (tapCount > 10) {
            Text(
                text = "¡Ganaste!",
                fontSize = 32.sp,
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            Text(
                text = "🎯", // Emoji o icono que quieras
                fontSize = 48.sp,
                modifier = Modifier.align(position)
            )
        }

        // Contador de taps en la esquina superior izquierda
        Text(
            text = "Taps: $tapCount",
            modifier = Modifier.align(Alignment.TopStart),
            fontSize = 20.sp
        )
    }
}

@Preview(showBackground = true)
@Composable
fun GameScreenPreview() {
    Repaso6Theme {
        GameScreen()
    }
}