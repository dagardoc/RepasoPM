package com.example.repaso2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.repaso2.ui.theme.Repaso2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Repaso2Theme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    PantallaSemaforo(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun PantallaSemaforo(modifier: Modifier = Modifier) {
    val colores = listOf("⚪", "🔴", "🟡", "🟢")
    var indiceColor by remember { mutableStateOf(0) }
    val emojiActual = colores[indiceColor]

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = emojiActual,
            fontSize = 100.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = {
            indiceColor = (indiceColor + 1) % colores.size
        }) {
            Text("Cambiar color")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewPantallaSemaforo() {
    Repaso2Theme {
        PantallaSemaforo()
    }
}
